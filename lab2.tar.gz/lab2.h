/******************************************************************************/
/* Copyright (C)                                                              */
/* File Name                   :  lab2.h                                      */
/* Principal Author            :  Lupeng                                      */
/* Subsystem Name              :  lab                                         */
/* Module Name                 :  lab                                         */
/* Language                    :  C	                                      */
/* Target Environment          :  Any	                                      */
/* Date of First Release       :  2014/09/20	                              */
/* Description                 :  This is lab2	                              */
/******************************************************************************/

/*
 * Revision log:
 *
 * Created by Lupeng, 2014/09/13
 *
 */

typedef struct DataNode
{   
    tLinkTableNode *pNext;
    char    *cmd;
    char    *desc;
    int     (*handler)();
}tDataNode;

tDataNode *FindCmd();

int ShowAllCmd(tLinkTable *head);
