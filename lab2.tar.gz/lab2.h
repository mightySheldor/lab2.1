/******************************************************************************/
/* Copyright (C)                                                              */
/* File Name                   :  lab2.h                                      */
/* Principal Author            :  Lupeng                                      */
/* Subsystem Name              :  lab2                                        */
/* Module Name                 :  lab2                                        */
/* Language                    :  C                                           */
/* Target Environment          :  Any                                         */
/* Date of First Release       :  2014/09/20                                  */
/* Description                 :  This is for lab2 program                    */
/******************************************************************************/

/*
 * Revision log:
 *
 * Created by Lupeng, 2014/09/20
 *
*/

#include<stdio.h>
#include<stdlib.h>

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10

int Help();

static tDataNode head[] =
{
     {"help", "this is help cmd!", Help, &head[1]},
     {"version", "lab1 program v1.0", NULL, NULL}
};

