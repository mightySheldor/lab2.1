This is lab2 program.

Build Procedure
    $ gcc lab2.c lab.c linklist.c -o lab2
    $ ./lab2 # you can input help & version cmd.
