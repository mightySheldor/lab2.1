/******************************************************************************/
/* Copyright (C)                                                              */
/* File Name                   :  lab.c                                       */
/* Principal Author            :  Lupeng                                      */
/* Subsystem Name              :  lab2                                        */
/* Module Name                 :  lab2                                        */
/* Language                    :  C                                           */
/* Target Environment          :  Any                                         */
/* Date of First Release       :  2014/09/13                                  */
/* Description                 :  This is lab1                                */
/******************************************************************************/

/*
 * Revision log:
 *
 * Created by Lupeng, 2014/09/13
 *
*/

#include<stdio.h>
#include<stdlib.h>
#include"linklist.h"
#include"lab2.h"

int Help()
{
     ShowAllCmd(head);     
     return 0;
}

