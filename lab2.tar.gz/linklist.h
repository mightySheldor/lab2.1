/******************************************************************************/
/* Copyright (C)                                                              */
/* File Name                   :  lisklist.h                                  */
/* Principal Author            :  Lupeng                                      */
/* Subsystem Name              :  lab2                                        */
/* Module Name                 :  linklist                                    */
/* Language                    :  C                                           */
/* Target Environment          :  Any                                         */
/* Date of First Release       :  2014/09/20                                  */
/* Description                 :  This is for lab2 program                    */
/******************************************************************************/

/*    
 * Revision log:
 *
 * Created by Lupeng, 2014/09/20
 *  
*/


typedef struct DataNode
{
    char    *cmd;
    char    *desc;
    int     (*handler)();
    struct  DataNode *next;
}tDataNode;

tDataNode *FindCmd(tDataNode *head, char *cmd);

int ShowAllCmd(tDataNode *head);

