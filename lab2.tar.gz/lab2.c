/******************************************************************************/
/* Copyright (C)                                                              */
/* File Name                   :  lab1.c                                      */
/* Principal Author            :  Lupeng                                      */
/* Subsystem Name              :  lab                                         */
/* Module Name                 :  lab                                         */
/* Language                    :  C	                                      */
/* Target Environment          :  Any	                                      */
/* Date of First Release       :  2014/09/13	                              */
/* Description                 :  This is lab2	                              */
/******************************************************************************/

/*
 * Revision log:
 *
 * Created by Lupeng, 2014/09/13
 *
*/

#include<stdio.h>
#include<stdlib.h>
#include"linklist.h"
#include"lab2.h"

main()
{
     while(1)
     {
         char cmd[CMD_MAX_LEN];
         printf("Input a cmd number > ");
         scanf("%s", cmd);
         tDataNode *p = FindCmd(head,cmd);
         if(p == NULL)
         {
             printf("This is a wrong cmd!\n");
             continue;
         }
         printf("%s - %s\n", p->cmd, p->desc);
         if(p->handler != NULL)
         {
             p->handler();
         }
           
     }
    
}


