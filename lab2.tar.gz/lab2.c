/******************************************************************************/
/* Copyright (C)                                                              */
/* File Name                   :  lab2.c                                      */
/* Principal Author            :  Lupeng                                      */
/* Subsystem Name              :  lab                                         */
/* Module Name                 :  lab                                         */
/* Language                    :  C	                                      */
/* Target Environment          :  Any	                                      */
/* Date of First Release       :  2014/09/20	                              */
/* Description                 :  This is lab2	                              */
/******************************************************************************/

/*
 * Revision log:
 *
 * Created by Lupeng, 2014/09/13
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include"linktable.h"
#include"lab2.h"

#define CMD_MAX_LEN 128
#define DESC_LEN    1024
#define CMD_NUM     10
        
tDataNode *FindCmd(tLinkTable *head, char *cmd)
{
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {   
        if(!strcmp(pNode->cmd, cmd))
        {
            return pNode;
        }
        pNode = (tDataNode*)GetNextLinkTableNode(head, (tLinkTableNode *)pNode);
    }   
    return NULL;
}   
 
int ShowAllCmd(tLinkTable *head)
{   
    tDataNode * pNode = (tDataNode*)GetLinkTableHead(head);
    while(pNode != NULL)
    {   
        printf("%s - %s\n", pNode->cmd, pNode->desc);
        pNode = (tDataNode*)GetNextLinkTableNode(head, (tLinkTableNode *)pNode);
    }   
    return 0;
}

